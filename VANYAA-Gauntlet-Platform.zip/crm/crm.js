const API_BASE = window.VANYAA_API_BASE || (location.protocol === "file:" ? "http://127.0.0.1:4177" : "");
const TOKEN_KEY = "vanyaa-crm-token";

const byId = (id) => document.getElementById(id);
const authHeaders = () => ({ Authorization: `Bearer ${localStorage.getItem(TOKEN_KEY) || ""}` });

let searchQuery = "";
let state = {
  players: [],
  matches: [],
  activity: [],
  stats: { registered: 0, alive: 0, totalMatches: 0, totalClaimed: 0 },
  tournament: {
    status: "registration",
    isRegistrationOpen: true,
    isPaused: false,
    isEnded: false,
    nextQueueSeed: 1,
    reigningChampionId: null,
    reigningChampionName: null,
    awaitingDecisionMatchId: null
  }
};

const escapeHtml = (value = "") =>
  String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");

const currency = (value) => `Rs ${Number(value) || 0}`;
const show = (id, visible) => byId(id).classList.toggle("hidden", !visible);

const setLoginMessage = (message, isError = false) => {
  byId("loginMessage").textContent = message;
  byId("loginMessage").classList.toggle("error", isError);
};

const setMatchMessage = (message, isError = false) => {
  byId("matchMessage").textContent = message;
  byId("matchMessage").classList.toggle("error", isError);
};

const setEditMessage = (message, isError = false) => {
  byId("editMessage").textContent = message;
  byId("editMessage").classList.toggle("error", isError);
};

const api = async (path, options = {}) => {
  const response = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...authHeaders(),
      ...(options.headers || {})
    }
  });
  const result = await response.json();
  if (response.status === 401) {
    localStorage.removeItem(TOKEN_KEY);
    showLoggedOut();
    throw new Error(result.error || "Admin login required");
  }
  if (!response.ok) throw new Error(result.error || "Request failed");
  return result;
};

const requireState = async () => {
  state = await api("/api/admin-state", { method: "GET" });
  render();
};

const showLoggedIn = () => {
  show("loginScreen", false);
  show("crmApp", true);
  show("logoutButton", true);
};

const showLoggedOut = () => {
  show("loginScreen", true);
  show("crmApp", false);
  show("logoutButton", false);
};

const sortedPlayers = () => [...state.players].sort((a, b) => a.seedNumber - b.seedNumber);

const playerHasOpenMatch = (playerId) =>
  state.matches.some(
    (match) =>
      (match.status === "scheduled" || match.status === "awaiting_decision") &&
      (match.playerAId === playerId || match.playerBId === playerId)
  );

const filteredPlayers = () => {
  const query = searchQuery.trim().toLowerCase();
  if (!query) return sortedPlayers();
  return sortedPlayers().filter((player) =>
    [
      player.fullName,
      player.gamingName,
      player.email,
      player.phoneNumber,
      player.discordId,
      player.valorantRank,
      player.status,
      player.approvalStatus
    ]
      .filter(Boolean)
      .some((value) => String(value).toLowerCase().includes(query))
  );
};

const renderStats = () => {
  byId("crmRegistered").textContent = state.stats.registered;
  byId("crmAlive").textContent = state.stats.alive;
  byId("crmMatches").textContent = state.stats.totalMatches;
  byId("crmClaimed").textContent = currency(state.stats.totalClaimed);
  byId("registrationLabel").textContent = state.tournament.isRegistrationOpen
    ? "Registration open"
    : "Registration closed";
  byId("statusLabel").textContent = `Status: ${state.tournament.status || "registration"}`;
  byId("championLabel").textContent = `Active player: ${state.tournament.reigningChampionName || "none"}`;
  byId("nextQueueLabel").textContent = `Next seed: #${state.tournament.nextQueueSeed || "-"}`;
};

const renderPlayers = () => {
  const rows = byId("playerRows");
  const players = filteredPlayers();

  rows.innerHTML = players
    .map((player) => {
      const moveLocked = state.matches.length > 0;
      const openLocked = playerHasOpenMatch(player.id);
      const isApproved = player.approvalStatus === "approved";
      return `
        <tr>
          <td class="mono">#${player.seedNumber}</td>
          <td>
            <strong>${escapeHtml(player.gamingName)}</strong><br />
            <span class="muted">${escapeHtml(player.fullName)} / ${escapeHtml(player.email || "no email")}</span><br />
            <span class="muted">${escapeHtml(player.phoneNumber || "-")} / ${escapeHtml(player.discordId || "-")}</span>
            <div class="row-actions">
              <button class="mini-button" data-edit="${player.id}" type="button">Edit</button>
              <button class="mini-button" data-move="-1" data-player="${player.id}" type="button" ${moveLocked ? "disabled" : ""}>Up</button>
              <button class="mini-button" data-move="1" data-player="${player.id}" type="button" ${moveLocked ? "disabled" : ""}>Down</button>
              <button class="mini-button" data-approval="${player.id}" data-value="approved" type="button" ${isApproved ? "disabled" : ""}>Approve</button>
              <button class="mini-button danger" data-approval="${player.id}" data-value="rejected" type="button" ${openLocked ? "disabled" : ""}>Reject</button>
              <button class="mini-button danger" data-remove="${player.id}" type="button" ${openLocked ? "disabled" : ""}>Remove</button>
            </div>
          </td>
          <td><span class="badge">${escapeHtml(player.valorantRank)}</span></td>
          <td class="mono">${player.wins}</td>
          <td class="mono">${currency(player.privateCredit)}</td>
          <td class="mono">${currency(player.totalClaimed)}</td>
          <td class="mono">${player.activeStreak || 0}</td>
          <td>${escapeHtml(player.approvalStatus || "approved")}</td>
          <td>${escapeHtml(player.status)}</td>
        </tr>
      `;
    })
    .join("");

  byId("emptyPlayers").classList.toggle("hidden", players.length > 0);
};

const renderMatches = () => {
  byId("crmMatchesList").innerHTML =
    state.matches
      .map(
        (match) => `
          <article class="match-card">
            <header>
              <div>
                <strong>Match ${match.round}: ${escapeHtml(match.playerAName)} vs ${escapeHtml(match.playerBName)}</strong>
                <small>${escapeHtml(match.playerARank)} vs ${escapeHtml(match.playerBRank)} / ${escapeHtml(match.status)}</small>
              </div>
              <span class="badge">Round ${match.round}</span>
            </header>
            ${
              match.status === "scheduled"
                ? `<div class="control-row">
                    <button class="button secondary" data-match="${match.id}" data-winner="${match.playerAId}" type="button">${escapeHtml(match.playerAName)} won</button>
                    <button class="button secondary" data-match="${match.id}" data-winner="${match.playerBId}" type="button">${escapeHtml(match.playerBName)} won</button>
                  </div>`
                : ""
            }
            ${
              match.status === "awaiting_decision"
                ? `<div class="control-row">
                    <span class="badge">Winner: ${escapeHtml(match.winnerName || "-")}</span>
                    <span class="badge">Active: ${currency(match.winnerPrizeAfter)}</span>
                    <button class="button primary" data-match="${match.id}" data-decision="continue" type="button">Continue</button>
                    <button class="button danger" data-match="${match.id}" data-decision="cash_out" type="button">Quit & claim</button>
                  </div>`
                : ""
            }
            ${
              match.status === "completed"
                ? `<small>Winner: ${escapeHtml(match.winnerName || "-")} / Decision: ${escapeHtml(match.decision || "saved")} / Active after win: ${currency(match.winnerPrizeAfter)}</small>`
                : ""
            }
          </article>
        `
      )
      .join("") || `<p class="empty panel">No matches created yet.</p>`;
};

const renderActivity = () => {
  byId("activityLog").innerHTML =
    state.activity
      .slice(0, 16)
      .map(
        (item) => `
          <article class="activity-item">
            <span>${escapeHtml(item.message)}</span>
            <small>${new Date(item.createdAt).toLocaleTimeString()}</small>
          </article>
        `
      )
      .join("") || `<p class="empty panel">Admin actions will appear here.</p>`;
};

const render = () => {
  renderStats();
  renderPlayers();
  renderMatches();
  renderActivity();
};

const openPlayerDialog = (playerId) => {
  const player = state.players.find((item) => item.id === playerId);
  if (!player) return;

  const form = byId("playerEditForm");
  form.elements.id.value = player.id;
  form.elements.fullName.value = player.fullName || "";
  form.elements.phoneNumber.value = player.phoneNumber || "";
  form.elements.email.value = player.email || "";
  form.elements.gamingName.value = player.gamingName || "";
  form.elements.discordId.value = player.discordId || "";
  form.elements.valorantRank.value = player.valorantRank || "Iron";
  form.elements.isYouTubeMember.value = String(Boolean(player.isYouTubeMember));
  form.elements.youtubeUsername.value = player.youtubeUsername || "";
  setEditMessage("");
  byId("playerDialog").showModal();
};

const exportPlayers = () => {
  const header = [
    "seed",
    "fullName",
    "gamingName",
    "email",
    "phoneNumber",
    "discordId",
    "valorantRank",
    "isYouTubeMember",
    "wins",
    "activeRs",
    "claimedRs",
    "activeStreak",
    "approvalStatus",
    "status"
  ];
  const escapeCsv = (value = "") => `"${String(value).replaceAll('"', '""')}"`;
  const rows = sortedPlayers().map((player) =>
    [
      player.seedNumber,
      player.fullName,
      player.gamingName,
      player.email,
      player.phoneNumber,
      player.discordId,
      player.valorantRank,
      player.isYouTubeMember ? "yes" : "no",
      player.wins,
      player.privateCredit,
      player.totalClaimed,
      player.activeStreak || 0,
      player.approvalStatus,
      player.status
    ]
      .map(escapeCsv)
      .join(",")
  );
  const blob = new Blob([[header.join(","), ...rows].join("\n")], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `vanyaa-players-${new Date().toISOString().slice(0, 10)}.csv`;
  link.click();
  URL.revokeObjectURL(url);
};

const postTournamentAction = async (action) => {
  try {
    const actionButtons = [
      byId("startTournament"),
      byId("pauseTournament"),
      byId("resumeTournament"),
      byId("restartTournament"),
      byId("resetTournament")
    ];
    actionButtons.forEach((button) => {
      button.disabled = true;
    });
    setMatchMessage(
      action === "restart"
        ? "Restarting the run..."
        : action === "reset"
          ? "Resetting the platform..."
          : `${action}...`
    );
    const result = await api(`/api/admin/tournament/${action}`, {
      method: "POST",
      body: "{}"
    });
    state = result.state || result;
    render();
    setMatchMessage(result.message || `${action} saved.`);
  } catch (error) {
    setMatchMessage(error.message, true);
  } finally {
    [
      byId("startTournament"),
      byId("pauseTournament"),
      byId("resumeTournament"),
      byId("restartTournament"),
      byId("resetTournament")
    ].forEach((button) => {
      button.disabled = false;
    });
  }
};

const openTournamentActionDialog = (action) => {
  const isReset = action === "reset";
  byId("tournamentActionValue").value = action;
  byId("tournamentActionEyebrow").textContent = isReset ? "Permanent reset" : "Fresh run";
  byId("tournamentActionTitle").textContent = isReset
    ? "Reset the entire platform?"
    : "Restart with the same players?";
  byId("tournamentActionDescription").textContent = isReset
    ? "This removes every player, match, result and activity entry. Registration will reopen at 0/51."
    : "Players and seed order stay. Match history, wins and private prize totals reset, then the first match is created immediately.";
  byId("confirmTournamentAction").textContent = isReset ? "Reset everything" : "Restart run";
  byId("tournamentActionDialog").showModal();
};

byId("loginForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const code = new FormData(form).get("code");

  try {
    setLoginMessage("Checking code...");
    const response = await fetch(`${API_BASE}/api/crm/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code })
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Login failed");

    localStorage.setItem(TOKEN_KEY, result.token);
    form.reset();
    setLoginMessage("");
    showLoggedIn();
    await requireState();
  } catch (error) {
    setLoginMessage(error.message, true);
  }
});

byId("logoutButton").addEventListener("click", () => {
  localStorage.removeItem(TOKEN_KEY);
  showLoggedOut();
});

byId("playerSearch").addEventListener("input", (event) => {
  searchQuery = event.target.value;
  renderPlayers();
});

byId("exportPlayers").addEventListener("click", exportPlayers);

byId("createNextMatch").addEventListener("click", async () => {
  try {
    setMatchMessage("Creating next match...");
    await api("/api/admin/gauntlet/next", { method: "POST", body: "{}" });
    setMatchMessage("Next match created.");
    await requireState();
  } catch (error) {
    setMatchMessage(error.message, true);
  }
});

byId("startTournament").addEventListener("click", () => postTournamentAction("start"));
byId("pauseTournament").addEventListener("click", () => postTournamentAction("pause"));
byId("resumeTournament").addEventListener("click", () => postTournamentAction("resume"));
byId("restartTournament").addEventListener("click", () => openTournamentActionDialog("restart"));
byId("resetTournament").addEventListener("click", () => openTournamentActionDialog("reset"));

byId("cancelTournamentAction").addEventListener("click", () => {
  byId("tournamentActionDialog").close();
});

byId("tournamentActionForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const action = byId("tournamentActionValue").value;
  byId("tournamentActionDialog").close();
  await postTournamentAction(action);
});

byId("playerRows").addEventListener("click", async (event) => {
  const editButton = event.target.closest("button[data-edit]");
  const moveButton = event.target.closest("button[data-move][data-player]");
  const approvalButton = event.target.closest("button[data-approval]");
  const removeButton = event.target.closest("button[data-remove]");

  try {
    if (editButton) {
      openPlayerDialog(editButton.dataset.edit);
      return;
    }

    if (moveButton) {
      await api(`/api/admin/players/${moveButton.dataset.player}/move-seed`, {
        method: "POST",
        body: JSON.stringify({ direction: Number(moveButton.dataset.move) })
      });
      await requireState();
    }

    if (approvalButton) {
      await api(`/api/admin/players/${approvalButton.dataset.approval}/approval`, {
        method: "POST",
        body: JSON.stringify({ approvalStatus: approvalButton.dataset.value })
      });
      await requireState();
    }

    if (removeButton) {
      if (!confirm("Remove this player from the tournament?")) return;
      await api(`/api/admin/players/${removeButton.dataset.remove}`, { method: "DELETE" });
      await requireState();
    }
  } catch (error) {
    setMatchMessage(error.message, true);
  }
});

byId("playerEditForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const payload = Object.fromEntries(new FormData(form).entries());
  const playerId = payload.id;
  delete payload.id;
  payload.isYouTubeMember = payload.isYouTubeMember === "true";

  try {
    setEditMessage("Saving...");
    await api(`/api/admin/players/${playerId}`, {
      method: "PATCH",
      body: JSON.stringify(payload)
    });
    setEditMessage("Saved.");
    byId("playerDialog").close();
    await requireState();
  } catch (error) {
    setEditMessage(error.message, true);
  }
});

byId("closePlayerDialog").addEventListener("click", () => {
  byId("playerDialog").close();
});

byId("crmMatchesList").addEventListener("click", async (event) => {
  const winnerButton = event.target.closest("button[data-match][data-winner]");
  const decisionButton = event.target.closest("button[data-match][data-decision]");

  try {
    if (winnerButton) {
      await api(`/api/admin/matches/${winnerButton.dataset.match}/winner`, {
        method: "POST",
        body: JSON.stringify({ winnerId: winnerButton.dataset.winner })
      });
      await requireState();
    }

    if (decisionButton) {
      await api(`/api/admin/matches/${decisionButton.dataset.match}/decision`, {
        method: "POST",
        body: JSON.stringify({ decision: decisionButton.dataset.decision })
      });
      await requireState();
    }
  } catch (error) {
    setMatchMessage(error.message, true);
  }
});

const startEvents = () => {
  if (!window.EventSource) return;
  const events = new EventSource(`${API_BASE}/api/events`);
  events.addEventListener("tournament", () => {
    if (localStorage.getItem(TOKEN_KEY)) requireState().catch(() => {});
  });
};

if (localStorage.getItem(TOKEN_KEY)) {
  showLoggedIn();
  requireState().catch((error) => setLoginMessage(error.message, true));
} else {
  showLoggedOut();
}
startEvents();
