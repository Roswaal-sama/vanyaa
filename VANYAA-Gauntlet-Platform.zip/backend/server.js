const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const PORT = Number(process.env.PORT || 4177);
const CRM_LOGIN_CODE = process.env.CRM_LOGIN_CODE || "VANYAA-ADMIN";
const WIN_VALUE = 50;
const MAX_PLAYERS = 51;
const ROOT = path.resolve(__dirname, "..");
const DATA_DIR = process.env.DON_DATA_DIR || path.join(__dirname, "data");
const STATE_FILE = path.join(DATA_DIR, "state.json");
const FIREBASE_COLLECTION = process.env.FIREBASE_COLLECTION || "vanyaa";
const FIREBASE_DOC = process.env.FIREBASE_DOC || "tournamentState";
const CORS_ORIGIN = process.env.CORS_ORIGIN || "*";

const sessions = new Map();
const eventClients = new Set();
let cachedState = null;
let firebaseStateDoc = null;

const initialState = {
  players: [],
  matches: [],
  activity: [],
  tournament: {
    status: "registration",
    isRegistrationOpen: true,
    isEnded: false,
    isPaused: false,
    nextQueueSeed: 1,
    reigningChampionId: null,
    awaitingDecisionMatchId: null,
    startedAt: null,
    endedAt: null
  }
};

const normalizePlayer = (player, index) => ({
  ...player,
  seedNumber: Number(player.seedNumber) || index + 1,
  fullName: player.fullName || "",
  phoneNumber: player.phoneNumber || "",
  email: player.email || "",
  gamingName: player.gamingName || "",
  discordId: player.discordId || "",
  valorantRank: player.valorantRank || "",
  isYouTubeMember: Boolean(player.isYouTubeMember),
  youtubeUsername: player.youtubeUsername || "",
  approvalStatus: player.approvalStatus || "approved",
  acceptedRules: Boolean(player.acceptedRules),
  wins: Number(player.wins) || 0,
  activeStreak: Number(player.activeStreak) || 0,
  rewardInternal: Number(player.rewardInternal) || 0,
  totalClaimed: Number(player.totalClaimed) || 0,
  status: player.status || "alive",
  createdAt: player.createdAt || now(),
  updatedAt: player.updatedAt || now()
});

const normalizeState = (state = {}) => {
  const tournament = {
    ...initialState.tournament,
    ...(state.tournament || {})
  };

  if (tournament.isEnded) tournament.status = "ended";
  else if (tournament.isPaused) tournament.status = "paused";
  else if (!tournament.isRegistrationOpen && tournament.status === "registration") tournament.status = "ready";

  return {
    ...initialState,
    ...state,
    players: Array.isArray(state.players) ? state.players.map(normalizePlayer) : [],
    matches: Array.isArray(state.matches) ? state.matches : [],
    activity: Array.isArray(state.activity) ? state.activity : [],
    tournament
  };
};

const configureFirebase = () => {
  const serviceAccountJson = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
  if (!serviceAccountJson && !process.env.FIREBASE_PROJECT_ID) return;

  try {
    const admin = require("firebase-admin");
    if (!admin.apps.length) {
      const credential = serviceAccountJson
        ? admin.credential.cert(JSON.parse(serviceAccountJson))
        : admin.credential.applicationDefault();
      admin.initializeApp({
        credential,
        projectId: process.env.FIREBASE_PROJECT_ID
      });
    }
    firebaseStateDoc = admin.firestore().collection(FIREBASE_COLLECTION).doc(FIREBASE_DOC);
    console.log(`Firebase persistence enabled: ${FIREBASE_COLLECTION}/${FIREBASE_DOC}`);
  } catch (error) {
    console.warn(`Firebase persistence unavailable, using local JSON: ${error.message}`);
    firebaseStateDoc = null;
  }
};

const ensureDataFile = () => {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(STATE_FILE)) {
    fs.writeFileSync(STATE_FILE, JSON.stringify(initialState, null, 2));
  }
};

const readState = () => {
  if (cachedState) return normalizeState(cachedState);
  ensureDataFile();
  cachedState = normalizeState(JSON.parse(fs.readFileSync(STATE_FILE, "utf8")));
  return cachedState;
};

const writeState = async (state) => {
  cachedState = normalizeState(state);
  if (firebaseStateDoc) {
    await firebaseStateDoc.set(cachedState, { merge: false });
    return;
  }
  ensureDataFile();
  fs.writeFileSync(STATE_FILE, JSON.stringify(cachedState, null, 2));
};

const loadState = async () => {
  configureFirebase();
  if (firebaseStateDoc) {
    const snapshot = await firebaseStateDoc.get();
    cachedState = snapshot.exists ? normalizeState(snapshot.data()) : normalizeState(initialState);
    if (!snapshot.exists) await firebaseStateDoc.set(cachedState, { merge: false });
    return;
  }
  cachedState = readState();
};

const json = (res, status, payload) => {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store"
  });
  res.end(JSON.stringify(payload));
};

const applyCors = (req, res) => {
  const origin = req.headers.origin || "";
  const allowed = CORS_ORIGIN.split(",").map((item) => item.trim()).filter(Boolean);
  const allowOrigin = CORS_ORIGIN === "*" || allowed.includes("*")
    ? "*"
    : allowed.includes(origin)
      ? origin
      : allowed[0] || origin;

  if (allowOrigin) res.setHeader("Access-Control-Allow-Origin", allowOrigin);
  res.setHeader("Vary", "Origin");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,PATCH,DELETE,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
};

const readBody = (req) =>
  new Promise((resolve, reject) => {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > 1_000_000) {
        reject(new Error("Request body too large"));
        req.destroy();
      }
    });
    req.on("end", () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch {
        reject(new Error("Invalid JSON"));
      }
    });
    req.on("error", reject);
  });

const now = () => new Date().toISOString();

const publicState = (state) => {
  const visiblePlayers = state.players.filter((player) => player.approvalStatus === "approved");
  const players = visiblePlayers.map((player) => ({
    id: player.id,
    seedNumber: player.seedNumber,
    gamingName: player.gamingName,
    valorantRank: player.valorantRank,
    wins: player.wins,
    status: player.status
  }));

  const matches = state.matches.map((match) => ({
    id: match.id,
    playerAId: match.playerAId,
    playerBId: match.playerBId,
    playerAName: match.playerAName,
    playerBName: match.playerBName,
    playerARank: match.playerARank,
    playerBRank: match.playerBRank,
    round: match.round,
    status: match.status,
    winnerName: match.winnerName || null
  }));

  return {
    players,
    matches,
    stats: {
      registered: visiblePlayers.length,
      alive: visiblePlayers.filter((player) => player.status === "alive").length,
      completedMatches: state.matches.filter((match) => match.status === "completed").length,
      totalMatches: state.matches.length,
      maxPlayers: MAX_PLAYERS,
      isRegistrationOpen: state.tournament.isRegistrationOpen
    },
    tournament: {
      isRegistrationOpen: state.tournament.isRegistrationOpen,
      isEnded: state.tournament.isEnded
    }
  };
};

const adminState = (state) => ({
  players: state.players.map((player) => ({
    ...player,
    privateCredit: player.rewardInternal
  })),
  matches: state.matches,
  activity: state.activity,
  stats: {
    registered: state.players.length,
    alive: state.players.filter((player) => player.status === "alive").length,
    pending: state.players.filter((player) => player.approvalStatus === "pending").length,
    rejected: state.players.filter((player) => player.approvalStatus === "rejected").length,
    completedMatches: state.matches.filter((match) => match.status === "completed").length,
    totalMatches: state.matches.length,
    totalClaimed: state.players.reduce((total, player) => total + (Number(player.totalClaimed) || 0), 0),
    maxPlayers: MAX_PLAYERS,
    isRegistrationOpen: state.tournament.isRegistrationOpen
  },
  tournament: {
    ...state.tournament,
    reigningChampionName: state.tournament.reigningChampionId
      ? playerById(state, state.tournament.reigningChampionId)?.gamingName || null
      : null
  }
});

const broadcast = (state = readState()) => {
  const payload = JSON.stringify(publicState(state));
  for (const client of eventClients) {
    client.write(`event: tournament\ndata: ${payload}\n\n`);
  }
};

const addActivity = (state, message) => {
  state.activity.unshift({
    id: crypto.randomUUID(),
    message,
    createdAt: now()
  });
  state.activity = state.activity.slice(0, 60);
};

const playerBySeed = (state, seedNumber) =>
  state.players.find((player) => player.seedNumber === seedNumber);

const playerById = (state, id) =>
  state.players.find((player) => player.id === id);

const sortedPlayers = (state) =>
  [...state.players].sort((a, b) => a.seedNumber - b.seedNumber);

const hasOpenMatch = (state) =>
  state.matches.some((match) => match.status === "scheduled" || match.status === "awaiting_decision");

const playerInOpenMatch = (state, playerId) =>
  state.matches.some(
    (match) =>
      (match.status === "scheduled" || match.status === "awaiting_decision") &&
      (match.playerAId === playerId || match.playerBId === playerId)
  );

const isMatchEligible = (player) =>
  Boolean(player) && player.status === "alive" && player.approvalStatus === "approved";

const nextEligibleFromSeed = (state, startSeed, excludeId = null) =>
  sortedPlayers(state).find(
    (player) => player.seedNumber >= startSeed && player.id !== excludeId && isMatchEligible(player)
  );

const createMatch = (state, playerA, playerB) => {
  if (!playerA || !playerB) throw new Error("Not enough queued players for the next match");
  if (!isMatchEligible(playerA) || !isMatchEligible(playerB)) {
    throw new Error("Only approved active players can be matched");
  }

  const match = {
    id: crypto.randomUUID(),
    playerAId: playerA.id,
    playerBId: playerB.id,
    playerAName: playerA.gamingName,
    playerBName: playerB.gamingName,
    playerARank: playerA.valorantRank,
    playerBRank: playerB.valorantRank,
    round: state.matches.length + 1,
    status: "scheduled",
    createdAt: now()
  };

  state.matches.push(match);
  addActivity(state, `Match #${match.round}: ${playerA.gamingName} vs ${playerB.gamingName}`);
  return match;
};

const createNextGauntletMatch = (state) => {
  if (state.tournament.isEnded) throw new Error("Tournament is already ended");
  if (state.tournament.isPaused) throw new Error("Tournament is paused");
  if (hasOpenMatch(state)) throw new Error("Resolve the current match or decision first");

  const champion = state.tournament.reigningChampionId
    ? playerById(state, state.tournament.reigningChampionId)
    : null;

  if (isMatchEligible(champion)) {
    const challenger = nextEligibleFromSeed(state, state.tournament.nextQueueSeed, champion.id);
    const match = createMatch(state, champion, challenger);
    state.tournament.nextQueueSeed = challenger.seedNumber + 1;
    return match;
  }

  state.tournament.reigningChampionId = null;
  const playerA = nextEligibleFromSeed(state, state.tournament.nextQueueSeed);
  const playerB = playerA ? nextEligibleFromSeed(state, playerA.seedNumber + 1, playerA.id) : null;
  const match = createMatch(state, playerA, playerB);
  state.tournament.nextQueueSeed = playerB.seedNumber + 1;
  return match;
};

const tryCreateNextGauntletMatch = (state) => {
  try {
    return createNextGauntletMatch(state);
  } catch (error) {
    if (String(error.message).includes("Not enough queued players")) {
      state.tournament.isEnded = true;
      state.tournament.status = "ended";
      state.tournament.endedAt = now();
      addActivity(state, "Tournament ended: no queued matchup remains");
      return null;
    }
    throw error;
  }
};

const closeRegistrationIfFull = (state) => {
  if (state.players.length >= MAX_PLAYERS) {
    state.tournament.isRegistrationOpen = false;
    if (state.tournament.status === "registration") state.tournament.status = "ready";
  }
};

const reseedPlayers = (state) => {
  sortedPlayers(state).forEach((player, index) => {
    player.seedNumber = index + 1;
  });
  state.tournament.nextQueueSeed = Math.min(state.tournament.nextQueueSeed, state.players.length + 1);
};

const requireFields = (payload, fields) => {
  for (const field of fields) {
    if (typeof payload[field] !== "string" || !payload[field].trim()) {
      throw new Error(`${field} is required`);
    }
  }
};

const getBearerToken = (req) => {
  const header = req.headers.authorization || "";
  return header.startsWith("Bearer ") ? header.slice(7) : "";
};

const isAuthorized = (req) => {
  const token = getBearerToken(req);
  const session = sessions.get(token);
  if (!session) return false;
  if (session.expiresAt < Date.now()) {
    sessions.delete(token);
    return false;
  }
  return true;
};

const routeApi = async (req, res, url) => {
  if (req.method === "GET" && url.pathname === "/api/public-state") {
    return json(res, 200, publicState(readState()));
  }

  if (req.method === "GET" && url.pathname === "/api/events") {
    res.writeHead(200, {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no"
    });
    eventClients.add(res);
    res.write(`event: tournament\ndata: ${JSON.stringify(publicState(readState()))}\n\n`);
    req.on("close", () => eventClients.delete(res));
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/register") {
    try {
      const payload = await readBody(req);
      requireFields(payload, ["fullName", "phoneNumber", "email", "gamingName", "discordId", "valorantRank"]);
      if (!payload.acceptedRules) throw new Error("Rules must be accepted");
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(payload.email.trim())) throw new Error("Valid email is required");

      const state = readState();
      if (!state.tournament.isRegistrationOpen) throw new Error("Registration is closed");
      if (state.players.length >= MAX_PLAYERS) throw new Error("Registration is full");

      const player = {
        id: crypto.randomUUID(),
        seedNumber: state.players.length + 1,
        fullName: payload.fullName.trim(),
        phoneNumber: payload.phoneNumber.trim(),
        email: payload.email.trim().toLowerCase(),
        gamingName: payload.gamingName.trim(),
        discordId: payload.discordId.trim(),
        valorantRank: payload.valorantRank.trim(),
        isYouTubeMember: Boolean(payload.isYouTubeMember),
        youtubeUsername: typeof payload.youtubeUsername === "string" ? payload.youtubeUsername.trim() : "",
        approvalStatus: "approved",
        acceptedRules: true,
        wins: 0,
        activeStreak: 0,
        rewardInternal: 0,
        totalClaimed: 0,
        status: "alive",
        createdAt: now(),
        updatedAt: now()
      };

      state.players.push(player);
      closeRegistrationIfFull(state);
      addActivity(state, `${player.gamingName} registered as seed #${player.seedNumber}`);
      await writeState(state);
      broadcast(state);
      return json(res, 201, {
        player: {
          id: player.id,
          seedNumber: player.seedNumber,
          gamingName: player.gamingName,
          valorantRank: player.valorantRank
        }
      });
    } catch (error) {
      return json(res, 400, { error: error.message });
    }
  }

  if (req.method === "POST" && url.pathname === "/api/crm/login") {
    try {
      const payload = await readBody(req);
      if (payload.code !== CRM_LOGIN_CODE) return json(res, 401, { error: "Invalid CRM code" });

      const token = crypto.randomBytes(32).toString("hex");
      sessions.set(token, { createdAt: Date.now(), expiresAt: Date.now() + 12 * 60 * 60 * 1000 });
      return json(res, 200, { token, expiresInSeconds: 43200 });
    } catch (error) {
      return json(res, 400, { error: error.message });
    }
  }

  if (url.pathname.startsWith("/api/admin")) {
    if (!isAuthorized(req)) return json(res, 401, { error: "Admin login required" });

    if (req.method === "GET" && url.pathname === "/api/admin-state") {
      return json(res, 200, adminState(readState()));
    }

    const tournamentActionMatch = url.pathname.match(/^\/api\/admin\/tournament\/(start|pause|resume|restart|reset)$/);
    if (req.method === "POST" && tournamentActionMatch) {
      try {
        const action = tournamentActionMatch[1];
        const state = readState();

        if (action === "start") {
          if (state.players.filter(isMatchEligible).length < 2) throw new Error("At least two approved players are needed");
          state.tournament.isRegistrationOpen = false;
          state.tournament.isPaused = false;
          state.tournament.isEnded = false;
          state.tournament.status = "running";
          state.tournament.startedAt = state.tournament.startedAt || now();
          addActivity(state, "Tournament started");
        }

        if (action === "pause") {
          state.tournament.isPaused = true;
          state.tournament.status = "paused";
          addActivity(state, "Tournament paused");
        }

        if (action === "resume") {
          state.tournament.isPaused = false;
          state.tournament.status = state.tournament.isEnded ? "ended" : "running";
          addActivity(state, "Tournament resumed");
        }

        if (action === "restart") {
          const approvedPlayers = state.players.filter(
            (player) => player.approvalStatus === "approved"
          );
          if (approvedPlayers.length < 2) {
            throw new Error("At least two approved players are needed to restart");
          }

          state.matches = [];
          state.players = state.players.map((player) => ({
            ...player,
            wins: 0,
            activeStreak: 0,
            rewardInternal: 0,
            totalClaimed: 0,
            status: player.approvalStatus === "approved" ? "alive" : player.status,
            updatedAt: now()
          }));
          state.tournament = {
            ...initialState.tournament,
            isRegistrationOpen: false,
            status: "running",
            startedAt: now()
          };
          addActivity(state, "Tournament restarted with existing players");
          createNextGauntletMatch(state);
        }

        if (action === "reset") {
          state.players = [];
          state.matches = [];
          state.activity = [];
          state.tournament = { ...initialState.tournament };
          addActivity(state, "Tournament reset");
        }

        await writeState(state);
        broadcast(state);
        return json(res, 200, {
          action,
          message:
            action === "restart"
              ? "Tournament restarted. The first match is ready."
              : action === "reset"
                ? "Platform reset. Registration is open."
                : `Tournament ${action} complete.`,
          state: adminState(state)
        });
      } catch (error) {
        return json(res, 400, { error: error.message });
      }
    }

    const editPlayerMatch = url.pathname.match(/^\/api\/admin\/players\/([^/]+)$/);
    if (req.method === "PATCH" && editPlayerMatch) {
      try {
        const payload = await readBody(req);
        const state = readState();
        const player = playerById(state, editPlayerMatch[1]);
        if (!player) throw new Error("Player not found");

        const editableFields = [
          "fullName",
          "phoneNumber",
          "email",
          "gamingName",
          "discordId",
          "valorantRank",
          "youtubeUsername"
        ];
        editableFields.forEach((field) => {
          if (typeof payload[field] === "string") player[field] = payload[field].trim();
        });
        if (typeof payload.isYouTubeMember === "boolean") player.isYouTubeMember = payload.isYouTubeMember;
        if (player.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(player.email)) throw new Error("Valid email is required");
        player.updatedAt = now();

        state.matches.forEach((match) => {
          if (match.playerAId === player.id) {
            match.playerAName = player.gamingName;
            match.playerARank = player.valorantRank;
          }
          if (match.playerBId === player.id) {
            match.playerBName = player.gamingName;
            match.playerBRank = player.valorantRank;
          }
          if (match.winnerId === player.id) match.winnerName = player.gamingName;
        });

        addActivity(state, `${player.gamingName} profile updated`);
        await writeState(state);
        broadcast(state);
        return json(res, 200, adminState(state));
      } catch (error) {
        return json(res, 400, { error: error.message });
      }
    }

    const approvalMatch = url.pathname.match(/^\/api\/admin\/players\/([^/]+)\/approval$/);
    if (req.method === "POST" && approvalMatch) {
      try {
        const payload = await readBody(req);
        if (!["approved", "pending", "rejected"].includes(payload.approvalStatus)) {
          throw new Error("approvalStatus must be approved, pending, or rejected");
        }

        const state = readState();
        const player = playerById(state, approvalMatch[1]);
        if (!player) throw new Error("Player not found");
        if (playerInOpenMatch(state, player.id)) throw new Error("Resolve this player's open match first");

        player.approvalStatus = payload.approvalStatus;
        if (payload.approvalStatus === "rejected") {
          player.status = "removed";
          player.rewardInternal = 0;
          if (state.tournament.reigningChampionId === player.id) state.tournament.reigningChampionId = null;
        } else if (player.status === "removed") {
          player.status = "alive";
        }
        player.updatedAt = now();

        addActivity(state, `${player.gamingName} marked ${player.approvalStatus}`);
        await writeState(state);
        broadcast(state);
        return json(res, 200, adminState(state));
      } catch (error) {
        return json(res, 400, { error: error.message });
      }
    }

    const softRemoveMatch = url.pathname.match(/^\/api\/admin\/players\/([^/]+)\/remove$/);
    if (req.method === "POST" && softRemoveMatch) {
      try {
        const state = readState();
        const player = playerById(state, softRemoveMatch[1]);
        if (!player) throw new Error("Player not found");
        if (playerInOpenMatch(state, player.id)) throw new Error("Resolve this player's open match first");

        player.status = "removed";
        player.rewardInternal = 0;
        player.activeStreak = 0;
        player.updatedAt = now();
        if (state.tournament.reigningChampionId === player.id) state.tournament.reigningChampionId = null;

        addActivity(state, `${player.gamingName} removed from the tournament`);
        await writeState(state);
        broadcast(state);
        return json(res, 200, adminState(state));
      } catch (error) {
        return json(res, 400, { error: error.message });
      }
    }

    const moveSeedMatch = url.pathname.match(/^\/api\/admin\/players\/([^/]+)\/move-seed$/);
    if (req.method === "POST" && moveSeedMatch) {
      try {
        const payload = await readBody(req);
        const direction = Number(payload.direction);
        if (![1, -1].includes(direction)) throw new Error("direction must be 1 or -1");

        const state = readState();
        if (state.matches.length > 0) throw new Error("Seed order is locked after the first match");

        const player = playerById(state, moveSeedMatch[1]);
        if (!player) throw new Error("Player not found");

        const targetSeed = player.seedNumber + direction;
        const target = playerBySeed(state, targetSeed);
        if (!target) throw new Error("No player in that seed slot");

        target.seedNumber = player.seedNumber;
        player.seedNumber = targetSeed;
        addActivity(state, `${player.gamingName} moved to seed #${player.seedNumber}`);
        await writeState(state);
        broadcast(state);
        return json(res, 200, adminState(state));
      } catch (error) {
        return json(res, 400, { error: error.message });
      }
    }

    const removePlayerMatch = url.pathname.match(/^\/api\/admin\/players\/([^/]+)$/);
    if (req.method === "DELETE" && removePlayerMatch) {
      try {
        const state = readState();
        const player = playerById(state, removePlayerMatch[1]);
        if (!player) throw new Error("Player not found");

        const hasMatchHistory = state.matches.some(
          (match) => match.playerAId === player.id || match.playerBId === player.id
        );
        if (playerInOpenMatch(state, player.id)) throw new Error("Resolve this player's open match first");

        if (hasMatchHistory) {
          player.status = "removed";
          player.rewardInternal = 0;
          player.activeStreak = 0;
          player.updatedAt = now();
          if (state.tournament.reigningChampionId === player.id) state.tournament.reigningChampionId = null;
          addActivity(state, `${player.gamingName} removed from the tournament`);
        } else {
          state.players = state.players.filter((item) => item.id !== player.id);
          state.tournament.isRegistrationOpen = state.players.length < MAX_PLAYERS && !state.tournament.startedAt;
          reseedPlayers(state);
          addActivity(state, `${player.gamingName} deleted from registrations`);
        }

        await writeState(state);
        broadcast(state);
        return json(res, 200, adminState(state));
      } catch (error) {
        return json(res, 400, { error: error.message });
      }
    }

    if (req.method === "POST" && url.pathname === "/api/admin/gauntlet/next") {
      try {
        const state = readState();
        const match = createNextGauntletMatch(state);
        if (state.tournament.status === "ready") state.tournament.status = "running";
        state.tournament.isRegistrationOpen = false;
        await writeState(state);
        broadcast(state);
        return json(res, 201, { match, tournament: state.tournament });
      } catch (error) {
        return json(res, 400, { error: error.message });
      }
    }

    if (req.method === "POST" && url.pathname === "/api/admin/matches") {
      return json(res, 400, { error: "Use Create next match to follow the gauntlet sequence" });
    }

    const winnerMatch = url.pathname.match(/^\/api\/admin\/matches\/([^/]+)\/winner$/);
    if (req.method === "POST" && winnerMatch) {
      try {
        const payload = await readBody(req);
        requireFields(payload, ["winnerId"]);

        const state = readState();
        const match = state.matches.find((item) => item.id === winnerMatch[1]);
        if (!match) throw new Error("Match not found");
        if (match.status !== "scheduled") throw new Error("Winner can only be set for a scheduled match");
        if (![match.playerAId, match.playerBId].includes(payload.winnerId)) {
          throw new Error("Winner must be one of the matched players");
        }

        const winner = state.players.find((player) => player.id === payload.winnerId);
        const loserId = payload.winnerId === match.playerAId ? match.playerBId : match.playerAId;
        const loser = state.players.find((player) => player.id === loserId);
        if (!winner || !loser) throw new Error("Matched player missing");

        const forfeitedAmount = loser.rewardInternal;

        winner.wins += 1;
        winner.activeStreak = (winner.activeStreak || 0) + 1;
        winner.rewardInternal += WIN_VALUE;
        winner.status = "alive";
        winner.updatedAt = now();
        loser.status = "eliminated";
        loser.rewardInternal = 0;
        loser.activeStreak = 0;
        loser.updatedAt = now();

        match.status = "awaiting_decision";
        match.winnerId = winner.id;
        match.winnerName = winner.gamingName;
        match.loserId = loser.id;
        match.winValue = WIN_VALUE;
        match.winnerPrizeAfter = winner.rewardInternal;
        match.loserPrizeForfeited = forfeitedAmount;
        match.completedAt = now();

        state.tournament.reigningChampionId = winner.id;
        state.tournament.awaitingDecisionMatchId = match.id;

        addActivity(
          state,
          `${winner.gamingName} defeated ${loser.gamingName} (+Rs ${WIN_VALUE}). ${loser.gamingName} forfeited Rs ${forfeitedAmount}.`
        );
        await writeState(state);
        broadcast(state);
        return json(res, 200, { match, winner });
      } catch (error) {
        return json(res, 400, { error: error.message });
      }
    }

    const decisionMatch = url.pathname.match(/^\/api\/admin\/matches\/([^/]+)\/decision$/);
    if (req.method === "POST" && decisionMatch) {
      try {
        const payload = await readBody(req);
        const decision = payload.decision;
        if (!["continue", "cash_out"].includes(decision)) {
          throw new Error("decision must be continue or cash_out");
        }

        const state = readState();
        const match = state.matches.find((item) => item.id === decisionMatch[1]);
        if (!match) throw new Error("Match not found");
        if (match.status !== "awaiting_decision") {
          throw new Error("Match is not awaiting a continue or cash-out decision");
        }
        if (state.tournament.awaitingDecisionMatchId !== match.id) {
          throw new Error("Resolve the current gauntlet decision first");
        }

        const winner = playerById(state, match.winnerId);
        if (!winner) throw new Error("Winner not found");

        match.status = "completed";
        match.decision = decision;
        match.decisionAt = now();
        state.tournament.awaitingDecisionMatchId = null;

        if (decision === "cash_out") {
          winner.totalClaimed = winner.rewardInternal;
          match.claimedAmount = winner.rewardInternal;
          winner.status = "cashed_out";
          winner.updatedAt = now();
          state.tournament.reigningChampionId = null;
          addActivity(state, `${winner.gamingName} quit and claimed Rs ${winner.rewardInternal}`);
        } else {
          state.tournament.reigningChampionId = winner.id;
          addActivity(state, `${winner.gamingName} continued with Rs ${winner.rewardInternal} active`);
        }

        const nextMatch = tryCreateNextGauntletMatch(state);
        if (!nextMatch && state.tournament.isEnded) {
          state.tournament.status = "ended";
          state.tournament.endedAt = now();
        }
        await writeState(state);
        broadcast(state);
        return json(res, 200, { match, nextMatch, tournament: state.tournament });
      } catch (error) {
        return json(res, 400, { error: error.message });
      }
    }
  }

  return json(res, 404, { error: "API route not found" });
};

const contentTypes = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg"
};

const serveStatic = (req, res, url) => {
  let pathname = decodeURIComponent(url.pathname);
  if (pathname === "/") pathname = "/user/";
  if (pathname === "/user") pathname = "/user/";
  if (pathname === "/crm") pathname = "/crm/";
  if (pathname.endsWith("/")) pathname += "index.html";

  const requestedPath = path.resolve(ROOT, pathname.replace(/^\/+/, ""));
  if (!requestedPath.startsWith(ROOT)) {
    res.writeHead(403);
    res.end("Forbidden");
    return;
  }

  fs.readFile(requestedPath, (error, buffer) => {
    if (error) {
      res.writeHead(404);
      res.end("Not found");
      return;
    }

    res.writeHead(200, {
      "Content-Type": contentTypes[path.extname(requestedPath)] || "application/octet-stream",
      "Cache-Control": "no-store"
    });
    res.end(buffer);
  });
};

const server = http.createServer((req, res) => {
  applyCors(req, res);
  if (req.method === "OPTIONS") {
    res.writeHead(204);
    res.end();
    return;
  }

  const url = new URL(req.url, `http://${req.headers.host || "127.0.0.1"}`);
  if (url.pathname.startsWith("/api/")) {
    routeApi(req, res, url).catch((error) => json(res, 500, { error: error.message }));
    return;
  }
  serveStatic(req, res, url);
});

loadState()
  .then(() => {
    server.listen(PORT, () => {
      console.log(`VANYAA backend running at http://127.0.0.1:${PORT}`);
      console.log(`User site: http://127.0.0.1:${PORT}/user/`);
      console.log(`Admin:     http://127.0.0.1:${PORT}/crm/`);
      console.log(`Admin code: ${CRM_LOGIN_CODE}`);
    });
  })
  .catch((error) => {
    console.error(`Unable to start VANYAA backend: ${error.message}`);
    process.exit(1);
  });
