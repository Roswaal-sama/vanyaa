const API_BASE = window.VANYAA_API_BASE || (location.protocol === "file:" ? "http://127.0.0.1:4177" : "");

const byId = (id) => document.getElementById(id);

let state = {
  players: [],
  matches: [],
  stats: { registered: 0, completedMatches: 0, maxPlayers: 51, isRegistrationOpen: true }
};

const escapeHtml = (value = "") =>
  String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");

const displayName = (player) => `${player.gamingName}`;

const fetchPublicState = async () => {
  const response = await fetch(`${API_BASE}/api/public-state`);
  if (!response.ok) throw new Error("Unable to load arena");
  state = await response.json();
  render();
};

const registrationIsOpen = () =>
  Boolean(state.stats.isRegistrationOpen) && state.stats.registered < (state.stats.maxPlayers || 51);

const renderRegistrationGate = () => {
  const form = byId("registrationForm");
  const button = byId("registrationButton");
  const open = registrationIsOpen();

  form.classList.toggle("is-closed", !open);
  form.querySelectorAll("input, select, button").forEach((control) => {
    control.disabled = !open;
  });
  button.textContent = open ? "Lock my slot" : "Registration Closed";

  if (!open) {
    showMessage("Registration Closed.");
  }
};

const renderStats = () => {
  byId("registeredCount").textContent = state.stats.registered;
  byId("completedCount").textContent = state.stats.completedMatches;
  byId("syncStatus").textContent = registrationIsOpen()
    ? `${state.stats.registered} players locked`
    : "Registration Closed";
  renderRegistrationGate();
};

const renderLeaderboard = () => {
  const rows = byId("leaderboardRows");
  const empty = byId("emptyLeaderboard");
  const players = [...state.players].sort((a, b) => b.wins - a.wins || a.seedNumber - b.seedNumber);

  rows.innerHTML = players
    .map(
      (player, index) => `
        <tr>
          <td>#${index + 1}</td>
          <td>
            <strong>${escapeHtml(displayName(player))}</strong><br />
            <span class="muted">Seed ${player.seedNumber}</span>
          </td>
          <td><span class="badge">${escapeHtml(player.valorantRank)}</span></td>
          <td>${player.wins}</td>
          <td>${escapeHtml(player.status)}</td>
        </tr>
      `
    )
    .join("");

  empty.classList.toggle("hidden", players.length > 0);
};

const renderMatches = () => {
  const wrap = byId("publicMatches");
  const statusCopy = {
    scheduled: "Match ready",
    awaiting_decision: "Winner locked",
    completed: "Complete"
  };

  wrap.innerHTML =
    state.matches
      .map(
        (match) => `
          <article class="match-card">
            <header>
              <div>
                <strong>${escapeHtml(match.playerAName)} vs ${escapeHtml(match.playerBName)}</strong>
                <small>${escapeHtml(match.playerARank)} vs ${escapeHtml(match.playerBRank)}</small>
              </div>
              <span class="badge">${escapeHtml(statusCopy[match.status] || match.status)}</span>
            </header>
            <small>${match.winnerName ? `Winner: ${escapeHtml(match.winnerName)}` : "Result pending"}</small>
          </article>
        `
      )
      .join("") || `<p class="empty panel">No matches scheduled yet.</p>`;
};

const render = () => {
  renderStats();
  renderLeaderboard();
  renderMatches();
};

const showMessage = (message, isError = false) => {
  const target = byId("registrationMessage");
  target.textContent = message;
  target.classList.toggle("error", isError);
};

byId("memberSelect").addEventListener("change", (event) => {
  byId("youtubeNameWrap").classList.toggle("hidden", event.target.value !== "yes");
});

byId("registrationForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const formData = new FormData(form);
  const payload = Object.fromEntries(formData.entries());
  payload.isYouTubeMember = payload.isYouTubeMember === "yes";
  payload.acceptedRules = formData.get("acceptedRules") === "on";

  try {
    showMessage("Locking your slot...");
    const response = await fetch(`${API_BASE}/api/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Registration failed");

    form.reset();
    byId("youtubeNameWrap").classList.add("hidden");
    showMessage(`You are in. Seed #${result.player.seedNumber} is yours.`);
    await fetchPublicState();
  } catch (error) {
    showMessage(error.message, true);
  }
});

const startEvents = () => {
  if (!window.EventSource) return;

  const events = new EventSource(`${API_BASE}/api/events`);
  events.addEventListener("tournament", (event) => {
    state = JSON.parse(event.data);
    render();
  });
  events.addEventListener("open", () => {
    byId("syncStatus").textContent = "Gauntlet live";
  });
  events.addEventListener("error", () => {
    byId("syncStatus").textContent = "Catching updates";
  });
};

const startVoid = () => {
  const canvas = byId("voidCanvas");
  const ctx = canvas.getContext("2d");
  const pointer = { x: 0, y: 0, active: false, pulse: 0 };
  const route = [
    { x: -240, y: 130, z: 0.75 },
    { x: -176, y: 78, z: 0.52 },
    { x: -96, y: 110, z: 0.35 },
    { x: -32, y: 28, z: 0.18 },
    { x: 42, y: 72, z: 0.28 },
    { x: 112, y: -10, z: 0.1 },
    { x: 190, y: 36, z: 0.34 },
    { x: 252, y: -78, z: 0.56 }
  ];
  const runners = Array.from({ length: 6 }, (_, index) => ({
    label: `P${index + 1}`,
    offset: index / 6,
    hue: index % 3
  }));

  const resize = () => {
    const rect = canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.floor(rect.width * dpr);
    canvas.height = Math.floor(rect.height * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  };

  const movePointer = (clientX, clientY) => {
    const rect = canvas.getBoundingClientRect();
    pointer.x = ((clientX - rect.left) / rect.width - 0.5) * 2;
    pointer.y = ((clientY - rect.top) / rect.height - 0.5) * 2;
    pointer.active = true;
  };

  canvas.addEventListener("pointermove", (event) => movePointer(event.clientX, event.clientY));
  canvas.addEventListener("pointerleave", () => {
    pointer.active = false;
  });
  canvas.addEventListener("pointerdown", (event) => {
    movePointer(event.clientX, event.clientY);
    pointer.pulse = 1;
  });

  const project = (point, cx, cy, px, py) => {
    const depth = 1 - point.z * 0.26;
    return {
      x: cx + (point.x + px * 44 * (1 - point.z)) * depth,
      y: cy + (point.y + py * 32 * (1 - point.z)) * depth,
      scale: depth
    };
  };

  const routePoint = (progress) => {
    const scaled = progress * (route.length - 1);
    const index = Math.floor(scaled);
    const next = Math.min(index + 1, route.length - 1);
    const t = scaled - index;
    const a = route[index];
    const b = route[next];
    return {
      x: a.x + (b.x - a.x) * t,
      y: a.y + (b.y - a.y) * t,
      z: a.z + (b.z - a.z) * t
    };
  };

  const drawCapsule = (x, y, width, height, radius) => {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
  };

  const draw = (time) => {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const width = canvas.width / dpr;
    const height = canvas.height / dpr;
    const cx = width / 2;
    const cy = height / 2;
    const px = pointer.active ? pointer.x : Math.sin(time * 0.00035) * 0.18;
    const py = pointer.active ? pointer.y : Math.cos(time * 0.00028) * 0.1;

    ctx.clearRect(0, 0, width, height);

    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    const glow = ctx.createRadialGradient(cx + px * 110, cy + py * 76, 16, cx, cy, Math.max(width, height) * 0.55);
    glow.addColorStop(0, "rgba(79, 209, 255, 0.18)");
    glow.addColorStop(0.28, "rgba(130, 92, 255, 0.1)");
    glow.addColorStop(0.64, "rgba(45, 255, 169, 0.045)");
    glow.addColorStop(1, "rgba(0, 0, 0, 0)");
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(cx + px * 88, cy + py * 54, Math.max(width, height) * 0.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    ctx.save();
    ctx.translate(px * 18, py * 10);

    for (let ring = 0; ring < 6; ring += 1) {
      const radius = 102 + ring * 46 + Math.sin(time * 0.00062 + ring) * 3;
      ctx.beginPath();
      ctx.ellipse(cx, cy + 46, radius * (1 + py * 0.03), radius * 0.24, 0, 0, Math.PI * 2);
      ctx.strokeStyle = ring % 2
        ? `rgba(93, 246, 197, ${0.12 - ring * 0.012})`
        : `rgba(122, 92, 255, ${0.13 - ring * 0.012})`;
      ctx.lineWidth = 0.8;
      ctx.stroke();
    }

    const projectedRoute = route.map((point) => project(point, cx, cy, px, py));
    ctx.beginPath();
    projectedRoute.forEach((point, index) => {
      if (index === 0) ctx.moveTo(point.x, point.y);
      else ctx.lineTo(point.x, point.y);
    });
    ctx.strokeStyle = "rgba(245, 247, 255, 0.12)";
    ctx.lineWidth = 11;
    ctx.lineCap = "round";
    ctx.stroke();

    ctx.beginPath();
    projectedRoute.forEach((point, index) => {
      if (index === 0) ctx.moveTo(point.x, point.y);
      else ctx.lineTo(point.x, point.y);
    });
    ctx.strokeStyle = "rgba(79, 209, 255, 0.66)";
    ctx.lineWidth = 1.7 + pointer.pulse * 1.4;
    ctx.shadowColor = "#4fd1ff";
    ctx.shadowBlur = 18;
    ctx.stroke();
    ctx.shadowBlur = 0;

    projectedRoute.forEach((point, index) => {
      ctx.beginPath();
      ctx.arc(point.x, point.y, 3.8 * point.scale, 0, Math.PI * 2);
      ctx.fillStyle = index % 2 ? "rgba(93, 246, 197, 0.88)" : "rgba(212, 184, 104, 0.84)";
      ctx.fill();
    });

    const apex = project({ x: 34, y: -174, z: 0.08 }, cx, cy, px, py);
    const left = project({ x: -164, y: 128, z: 0.5 }, cx, cy, px, py);
    const right = project({ x: 238, y: 92, z: 0.38 }, cx, cy, px, py);
    const middle = project({ x: 20, y: 42, z: 0.16 }, cx, cy, px, py);

    ctx.beginPath();
    ctx.moveTo(apex.x, apex.y);
    ctx.lineTo(right.x, right.y);
    ctx.lineTo(left.x, left.y);
    ctx.closePath();
    ctx.strokeStyle = "rgba(122, 92, 255, 0.3)";
    ctx.lineWidth = 1;
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(apex.x, apex.y);
    ctx.lineTo(middle.x, middle.y);
    ctx.lineTo(left.x, left.y);
    ctx.moveTo(middle.x, middle.y);
    ctx.lineTo(right.x, right.y);
    ctx.strokeStyle = "rgba(79, 209, 255, 0.34)";
    ctx.shadowColor = "#4fd1ff";
    ctx.shadowBlur = 12;
    ctx.stroke();
    ctx.shadowBlur = 0;

    runners.forEach((runner, index) => {
      const progress = (time * 0.000055 + runner.offset + pointer.pulse * 0.02) % 1;
      const point = project(routePoint(progress), cx, cy, px, py);
      const lift = Math.sin(time * 0.006 + index) * 2.4;
      const colors = [
        ["rgba(79, 209, 255, 0.95)", "#4fd1ff"],
        ["rgba(93, 246, 197, 0.95)", "#5df6c5"],
        ["rgba(212, 184, 104, 0.95)", "#d4b868"]
      ][runner.hue];

      ctx.save();
      ctx.translate(point.x, point.y + lift);
      ctx.scale(point.scale, point.scale);
      ctx.fillStyle = "rgba(0, 0, 0, 0.34)";
      ctx.beginPath();
      ctx.ellipse(0, 18, 24, 6, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = colors[0];
      ctx.shadowColor = colors[1];
      ctx.shadowBlur = 16;
      ctx.beginPath();
      ctx.arc(-9, -11, 5.2, 0, Math.PI * 2);
      ctx.fill();
      drawCapsule(-4, -14, 25, 18, 9);
      ctx.fill();
      ctx.shadowBlur = 0;

      ctx.fillStyle = "rgba(5, 7, 12, 0.86)";
      drawCapsule(-18, -38, 42, 19, 9);
      ctx.fill();
      ctx.strokeStyle = "rgba(245, 247, 255, 0.16)";
      ctx.stroke();
      ctx.fillStyle = "#f7f9ff";
      ctx.font = "800 10px JetBrains Mono, monospace";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(runner.label, 3, -28.5);
      ctx.restore();
    });

    ctx.restore();
    pointer.pulse *= 0.9;
    requestAnimationFrame(draw);
  };

  resize();
  addEventListener("resize", resize);
  requestAnimationFrame(draw);
};

fetchPublicState().catch((error) => {
  byId("syncStatus").textContent = "Arena warming up";
  showMessage(error.message, true);
});
startEvents();
startVoid();

document.querySelectorAll(".magnetic").forEach((element) => {
  element.addEventListener("pointermove", (event) => {
    const rect = element.getBoundingClientRect();
    const x = (event.clientX - rect.left - rect.width / 2) * 0.12;
    const y = (event.clientY - rect.top - rect.height / 2) * 0.18;
    element.style.transform = `translate3d(${x}px, ${y}px, 0)`;
  });
  element.addEventListener("pointerleave", () => {
    element.style.transform = "";
  });
});
